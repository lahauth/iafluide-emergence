import streamlit as st
import numpy as np

st.title("IA Fluide – Réseau Ψ interactif")

st.markdown("Simulation d’un Ψ-agent auto-régulé selon la loi fluide")

rho = st.slider("ρ (densité)", 0.0, 1.0, 0.5)
v_abs = st.slider("v_abs (vitesse émergence)", 0.0, 1.5, 0.7)
d2rho = st.slider("∂²ρ/∂t² (accélération densité)", -1.0, 1.0, 0.0)

if v_abs <= 0.8 and rho < 0.6 and d2rho >= 0:
    st.success("Loi fluide satisfaite – état stable ✅")
else:
    st.error("Loi fluide violée – action corrective nécessaire ⚠️")
